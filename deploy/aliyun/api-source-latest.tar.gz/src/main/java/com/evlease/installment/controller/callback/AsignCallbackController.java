package com.evlease.installment.controller.callback;

import com.evlease.installment.asign.AsignService;
import com.evlease.installment.common.ApiException;
import com.evlease.installment.juzheng.NotaryService;
import com.evlease.installment.model.Contract;
import com.evlease.installment.model.Order;
import com.evlease.installment.repo.ContractRepository;
import com.evlease.installment.repo.OrderRepository;
import com.evlease.installment.service.OrderLogService;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/callbacks/asign")
public class AsignCallbackController {
  private static final Logger log = LoggerFactory.getLogger(AsignCallbackController.class);
  private final AsignService asignService;
  private final ContractRepository contractRepository;
  private final OrderRepository orderRepository;
  private final OrderLogService orderLogService;
  private final NotaryService notaryService;

  public AsignCallbackController(
    AsignService asignService,
    ContractRepository contractRepository,
    OrderRepository orderRepository,
    OrderLogService orderLogService,
    NotaryService notaryService
  ) {
    this.asignService = asignService;
    this.contractRepository = contractRepository;
    this.orderRepository = orderRepository;
    this.orderLogService = orderLogService;
    this.notaryService = notaryService;
  }

  @PostMapping("/contract")
  public String contractCallback(@RequestBody Map<String, Object> payload) {
    if (payload == null || payload.isEmpty()) return "ok";
    String sign = payload.containsKey("sign") ? String.valueOf(payload.get("sign")) : "";
    Map<String, Object> verifyPayload = new HashMap<>(payload);
    verifyPayload.remove("sign");
    verifyPayload.remove("remark");
    try {
      if (!asignService.verifyCallback(verifyPayload, sign)) {
        log.warn("Asign callback signature invalid: {}", verifyPayload);
        return "fail";
      }
    } catch (Exception ex) {
      log.warn("Asign callback signature verify failed: {}", ex.getMessage());
      return "fail";
    }

    String contractNo = String.valueOf(payload.getOrDefault("contractNo", ""));
    if (contractNo.isBlank()) return "ok";
    Contract contract = contractRepository.findByContractNo(contractNo);
    if (contract == null) return "ok";

    String status = String.valueOf(payload.getOrDefault("status", ""));
    String signTime = String.valueOf(payload.getOrDefault("signTime", ""));
    try {
      switch (status) {
        case "2" -> {
          asignService.applySignedContract(contract, signTime);
          try {
            String fileUrl = asignService.downloadContract(contractNo);
            if (fileUrl != null && !fileUrl.isBlank()) {
              contract.setFileUrl(fileUrl);
            }
          } catch (Exception ex) {
            log.warn("Download contract failed: {}", ex.getMessage());
          }
        }
        case "3" -> asignService.applyVoidContract(contract, "EXPIRED");
        case "4" -> asignService.applyVoidContract(contract, "REFUSED");
        case "-3" -> asignService.applyFailedContract(contract, "FAILED");
        default -> {
          return "ok";
        }
      }
      contractRepository.save(contract);
    } catch (Exception ex) {
      throw new ApiException(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    Order order = orderRepository.findById(contract.getOrderId()).orElse(null);
    if (order != null) {
      orderLogService.add(order, "CONTRACT_CALLBACK", "CALLBACK", l -> l.setContractStatus(contract.getStatus()));
      orderRepository.save(order);
      if ("SIGNED".equalsIgnoreCase(contract.getStatus())) {
        try {
          applyNotary(order);
        } catch (Exception ex) {
          order.setNotaryStatus("FAILED");
          orderLogService.add(order, "NOTARY_AUTO_FAILED", "CALLBACK", l -> l.setActor(ex.getMessage()));
          orderRepository.save(order);
        }
      }
    }

    return "ok";
  }

  @PostMapping("/auth")
  public Map<String, Object> authCallback(@RequestBody Map<String, Object> payload) {
    if (payload == null || payload.isEmpty()) return Map.of("success", true);
    String sign = asText(payload.get("sign"));
    String result = asText(payload.get("result"));
    String serialNo = asText(payload.get("serialNo"));
    String name = decode(asText(payload.get("name")));
    String idNo = decode(asText(payload.get("idNo")));
    String bizId = decode(asText(payload.get("bizId")));

    boolean verified = false;
    try {
      verified = asignService.verifyAuthCallback(name, idNo, serialNo, result, sign);
      if (!verified) {
        log.warn("Asign auth callback signature invalid: serialNo={}", serialNo);
      }
    } catch (Exception ex) {
      log.warn("Asign auth callback signature verify failed: {}", ex.getMessage());
    }

    Order order = null;
    if (bizId != null && !bizId.isBlank()) {
      order = orderRepository.findById(bizId).orElse(null);
    }
    if (order == null && idNo != null && !idNo.isBlank()) {
      order = orderRepository.findFirstByIdCardNumberOrderByCreatedAtDesc(idNo).orElse(null);
    }
    if (order != null) {
      order.setAsignSerialNo(serialNo);
      order.setAsignAuthResult(result);
      orderLogService.add(order, "ASIGN_AUTH_CALLBACK", "CALLBACK", l -> l.setActor(result));
      orderRepository.save(order);
    }

    return Map.of("success", true, "verified", verified);
  }

  private String asText(Object value) {
    return value == null ? "" : String.valueOf(value);
  }

  private String decode(String value) {
    if (value == null || value.isBlank()) return "";
    try {
      return URLDecoder.decode(value, StandardCharsets.UTF_8);
    } catch (Exception ex) {
      return value;
    }
  }

  private void applyNotary(Order order) throws Exception {
    if (order.getNotaryOrderNo() != null && !order.getNotaryOrderNo().isBlank()) {
      return;
    }
    if (!order.isKycCompleted()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "KYC not completed");
    }
    String outOrderNo = notaryService.applyLeaseNotary(order);
    order.setNotaryOrderNo(outOrderNo);
    order.setNotaryStatus("10");
    orderLogService.add(order, "NOTARY_APPLY", "CALLBACK", l -> l.setActor("合同签署完成后自动发起"));
    orderRepository.save(order);
  }
}
