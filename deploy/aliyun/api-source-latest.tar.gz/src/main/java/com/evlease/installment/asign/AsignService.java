package com.evlease.installment.asign;

import com.evlease.installment.common.ApiException;
import com.evlease.installment.config.AppProperties;
import com.evlease.installment.model.Contract;
import com.evlease.installment.model.Order;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class AsignService {
  private static final List<String> USER_EXISTS_CODES = List.of("100021");
  private final AsignClient client;
  private final AsignConfig config;
  private final AppProperties appProperties;
  private final ObjectMapper objectMapper;

  public AsignService(AsignClient client, AsignConfig config, AppProperties appProperties) {
    this.client = client;
    this.config = config;
    this.appProperties = appProperties;
    this.objectMapper = new ObjectMapper();
  }

  public record PrepareResult(
    String contractNo,
    String templateNo,
    String signUrl,
    String previewUrl,
    String companyAccount,
    String userAccount
  ) {}

  public record AuthUrlResult(String serialNo, String authUrl) {}

  public PrepareResult prepareContract(Order order, String contractNoOverride, String templateNoOverride) throws Exception {
    ensureConfigured();
    String contractNo = resolveContractNo(order, contractNoOverride);
    String templateNo = resolveTemplateNo(templateNoOverride);
    String companyAccount = ensureCompanyUser();
    String userAccount = ensurePersonalUser(order);

    Map<String, Object> createParams = new HashMap<>();
    createParams.put("contractNo", contractNo);
    createParams.put("contractName", buildContractName(order));
    createParams.put("signOrder", config.getSignOrder());
    // 设置合同有效期为当前日期 + 30天
    java.time.LocalDate validityDate = java.time.LocalDate.now().plusDays(30);
    createParams.put("validityDate", validityDate.toString());

    Map<String, Object> template = new HashMap<>();
    template.put("templateNo", templateNo);
    Map<String, Object> fillData = buildTemplateFill(order);
    if (!fillData.isEmpty()) template.put("fillData", fillData);
    createParams.put("templates", List.of(template));

    String notifyUrl = resolveNotifyUrl();
    if (!notifyUrl.isBlank()) createParams.put("notifyUrl", notifyUrl);
    String callbackUrl = resolveCallbackUrl();
    if (!callbackUrl.isBlank()) createParams.put("callbackUrl", callbackUrl);
    String userNotifyUrl = resolveUserNotifyUrl();
    if (!userNotifyUrl.isBlank()) createParams.put("userNotifyUrl", userNotifyUrl);
    if (config.getRedirectUrl() != null && !config.getRedirectUrl().isBlank()) {
      createParams.put("redirectUrl", config.getRedirectUrl());
    }

    Map<String, Object> createResult = client.post("/contract/createContract", createParams);
    String previewUrl = extractPreviewUrl(createResult);

    List<Map<String, Object>> signers = List.of(
      buildSigner(companyAccount, contractNo, config.getCompanySignType(), config.getCompanySignKey(), 1, true),
      buildSigner(userAccount, contractNo, config.getUserSignType(), config.getUserSignKey(), 2, false)
    );
    Map<String, Object> signResult = client.postList("/contract/addSigner", signers);
    String signUrl = extractSignUrl(signResult, userAccount);

    return new PrepareResult(contractNo, templateNo, signUrl, previewUrl, companyAccount, userAccount);
  }

  public AuthUrlResult requestPersonIdentifyUrl(Order order) throws Exception {
    ensureConfigured();
    if (order.getRealName() == null || order.getRealName().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "renter name missing");
    }
    if (order.getIdCardNumber() == null || order.getIdCardNumber().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "renter idCard missing");
    }
    Map<String, Object> payload = new HashMap<>();
    payload.put("realName", order.getRealName());
    payload.put("idCardNo", order.getIdCardNumber());
    payload.put("bizId", order.getId());
    String notifyUrl = resolveAuthNotifyUrl();
    if (!notifyUrl.isBlank()) payload.put("notifyUrl", notifyUrl);
    String redirectUrl = resolveAuthRedirectUrl();
    if (!redirectUrl.isBlank()) payload.put("redirectUrl", redirectUrl);
    Map<String, Object> result = client.post("/auth/person/identifyUrl", payload);
    Map<String, Object> data = extractData(result);
    String serialNo = data == null ? "" : String.valueOf(data.getOrDefault("serialNo", ""));
    String authUrl = extractAuthUrl(data);
    return new AuthUrlResult(serialNo, authUrl);
  }

  public String downloadContract(String contractNo) throws Exception {
    Map<String, Object> result = client.post("/contract/downloadContract", Map.of(
      "contractNo", contractNo,
      "downloadFileType", 1,
      "force", 1
    ));
    Map<String, Object> data = extractData(result);
    if (data == null) return "";
    String base64 = String.valueOf(data.getOrDefault("data", "")).trim();
    if (base64.isBlank()) return "";
    byte[] bytes = Base64.getDecoder().decode(base64);
    String filename = "contract_" + sanitize(contractNo) + ".pdf";
    Path dir = resolveUploadDir();
    Files.createDirectories(dir);
    Path target = dir.resolve(filename).normalize();
    if (!target.startsWith(dir)) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "invalid file path");
    }
    Files.write(target, bytes);
    return "/uploads/" + filename;
  }

  public void applySignedContract(Contract contract, String signTime) {
    contract.setStatus("SIGNED");
    contract.setSignedAt(parseInstant(signTime));
    contract.setUpdatedAt(Instant.now());
  }

  public void applyVoidContract(Contract contract, String reason) {
    contract.setStatus("VOID");
    contract.setVoidReason(reason);
    contract.setUpdatedAt(Instant.now());
  }

  public void applyFailedContract(Contract contract, String reason) {
    contract.setStatus("FAILED");
    contract.setVoidReason(reason);
    contract.setUpdatedAt(Instant.now());
  }

  public boolean verifyCallback(Map<String, Object> payload, String sign) throws Exception {
    if (config.getPublicKey() == null || config.getPublicKey().isBlank()) return true;
    return AsignCryptoUtil.verify(payload, sign, config.getPublicKey());
  }

  public boolean verifyAuthCallback(String name, String idNo, String serialNo, String result, String sign) throws Exception {
    if (config.getPublicKey() == null || config.getPublicKey().isBlank()) return true;
    return AsignCryptoUtil.verifyAuthCallback(name, idNo, serialNo, result, sign, config.getPublicKey());
  }

  private void ensureConfigured() {
    if (config.getAppId() == null || config.getAppId().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "asign appId missing");
    }
    if (config.getPrivateKey() == null || config.getPrivateKey().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "asign privateKey missing");
    }
    if (resolveTemplateNo("") == null || resolveTemplateNo("").isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "asign templateNo missing");
    }
  }

  private String resolveContractNo(Order order, String override) {
    if (override != null && !override.isBlank()) return override.trim();
    return order.getId();
  }

  private String resolveTemplateNo(String override) {
    if (override != null && !override.isBlank()) return override.trim();
    return config.getTemplateNo() == null ? "" : config.getTemplateNo().trim();
  }

  private String buildContractName(Order order) {
    String name = order.getProductName();
    if (name == null || name.isBlank()) return "租赁合同";
    return name + " 租赁合同";
  }

  private String resolveNotifyUrl() {
    if (config.getNotifyUrl() != null && !config.getNotifyUrl().isBlank()) return config.getNotifyUrl();
    String base = appProperties.getPublicBaseUrl();
    if (base == null || base.isBlank()) return "";
    return base + "/api/callbacks/asign/contract";
  }

  private String resolveAuthNotifyUrl() {
    if (config.getAuthNotifyUrl() != null && !config.getAuthNotifyUrl().isBlank()) return config.getAuthNotifyUrl();
    String base = appProperties.getPublicBaseUrl();
    if (base == null || base.isBlank()) return "";
    return base + "/api/callbacks/asign/auth";
  }

  private String resolveAuthRedirectUrl() {
    if (config.getAuthRedirectUrl() != null && !config.getAuthRedirectUrl().isBlank()) return config.getAuthRedirectUrl();
    return "";
  }

  private String resolveCallbackUrl() {
    if (config.getCallbackUrl() != null && !config.getCallbackUrl().isBlank()) return config.getCallbackUrl();
    String base = appProperties.getPublicBaseUrl();
    if (base == null || base.isBlank()) return "";
    return base + "/api/callbacks/asign/contract";
  }

  private String resolveUserNotifyUrl() {
    if (config.getUserNotifyUrl() != null && !config.getUserNotifyUrl().isBlank()) return config.getUserNotifyUrl();
    return "";
  }

  private String ensureCompanyUser() throws Exception {
    String account = config.getCompanyAccount();
    if (account == null || account.isBlank()) {
      account = config.getCompanyCertNo();
    }
    if (account == null || account.isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "asign company account missing");
    }
    Map<String, Object> payload = new HashMap<>();
    payload.put("account", account);
    payload.put("companyName", config.getCompanyName());
    payload.put("creditCode", config.getCompanyCertNo());
    payload.put("name", config.getLegalName());
    payload.put("idCard", config.getLegalCertNo());
    payload.put("mobile", resolveCompanyMobile());
    payload.put("contactName", resolveCompanyContactName());
    payload.put("contactIdCard", resolveCompanyContactIdCard());
    if (config.getCompanySerialNo() != null && !config.getCompanySerialNo().isBlank()) {
      payload.put("serialNo", config.getCompanySerialNo());
    }
    client.postAllowCodes("/v2/user/addEnterpriseUser", payload, USER_EXISTS_CODES);
    return account;
  }

  private String ensurePersonalUser(Order order) throws Exception {
    if (order.getRealName() == null || order.getRealName().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "renter name missing");
    }
    if (order.getIdCardNumber() == null || order.getIdCardNumber().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "renter idCard missing");
    }
    if (order.getPhone() == null || order.getPhone().isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "renter phone missing");
    }
    String account = resolveUserAccount(order);
    // 临时强制启用陌生人模式进行测试
    boolean forceStranger = true;
    if (forceStranger || config.isUseStranger()) {
      Map<String, Object> payload = new HashMap<>();
      payload.put("account", account);
      payload.put("userType", 2);
      payload.put("name", order.getRealName());
      payload.put("mobile", order.getPhone());
      client.postAllowCodes("/v2/user/addStranger", payload, USER_EXISTS_CODES);
      return account;
    }
    String serialNo = order.getAsignSerialNo();
    String authResult = order.getAsignAuthResult();
    if (serialNo == null || serialNo.isBlank()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "请先完成爱签实名认证（客户需在H5订单详情页点击'去实名认证'）");
    }
    // 检查认证结果，"1" 表示认证成功
    if (authResult == null || !authResult.equals("1")) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "爱签实名认证未完成或失败，请客户重新进行人脸认证");
    }
    Map<String, Object> payload = new HashMap<>();
    payload.put("account", account);
    payload.put("serialNo", serialNo);
    payload.put("idCard", order.getIdCardNumber());
    payload.put("idCardType", 1);
    payload.put("mobile", order.getPhone());
    // 签约密码：使用手机号后6位
    String signPwd = order.getPhone().length() >= 6 
        ? order.getPhone().substring(order.getPhone().length() - 6) 
        : "123456";
    payload.put("signPwd", signPwd);
    payload.put("isSignPwdNotice", 1); // 短信通知用户签约密码
    payload.put("isNotice", 1); // 签署时发送短信
    client.postAllowCodes("/v2/user/addPersonalUser", payload, USER_EXISTS_CODES);
    return account;
  }

  private String resolveUserAccount(Order order) {
    if (order.getIdCardNumber() != null && !order.getIdCardNumber().isBlank()) {
      return order.getIdCardNumber();
    }
    return order.getPhone();
  }

  private String resolveCompanyMobile() {
    if (config.getCompanyMobile() != null && !config.getCompanyMobile().isBlank()) {
      return config.getCompanyMobile();
    }
    if (config.getLegalPhone() != null && !config.getLegalPhone().isBlank()) {
      return config.getLegalPhone();
    }
    return "";
  }

  private String resolveCompanyContactName() {
    if (config.getCompanyContactName() != null && !config.getCompanyContactName().isBlank()) {
      return config.getCompanyContactName();
    }
    return config.getLegalName();
  }

  private String resolveCompanyContactIdCard() {
    if (config.getCompanyContactIdCard() != null && !config.getCompanyContactIdCard().isBlank()) {
      return config.getCompanyContactIdCard();
    }
    return config.getLegalCertNo();
  }

  private Map<String, Object> buildSigner(
    String account,
    String contractNo,
    int signType,
    String signKey,
    int signOrder,
    boolean companySigner
  ) throws Exception {
    Map<String, Object> signer = new HashMap<>();
    signer.put("account", account);
    signer.put("contractNo", contractNo);
    signer.put("signType", signType);
    if (config.getSignOrder() == 2) {
      signer.put("signOrder", String.valueOf(signOrder));
    }
    List<Map<String, Object>> strategy = parseStrategy(
      companySigner ? config.getCompanySignStrategyJson() : config.getUserSignStrategyJson(),
      signKey
    );
    if (!strategy.isEmpty()) signer.put("signStrategyList", strategy);
    return signer;
  }

  private List<Map<String, Object>> parseStrategy(String json, String signKey) throws Exception {
    if (json != null && !json.isBlank()) {
      return objectMapper.readValue(json, new TypeReference<>() {});
    }
    if (signKey == null || signKey.isBlank()) return List.of();
    Map<String, Object> strategy = new HashMap<>();
    strategy.put("attachNo", config.getSignAttachNo());
    strategy.put("locationMode", config.getSignLocationMode());
    strategy.put("signKey", signKey);
    return List.of(strategy);
  }

  private Map<String, Object> buildTemplateFill(Order order) throws Exception {
    if (config.getTemplateFillJson() == null || config.getTemplateFillJson().isBlank()) return Map.of();
    Map<String, Object> raw = objectMapper.readValue(config.getTemplateFillJson(), new TypeReference<>() {});
    Map<String, String> vars = buildTemplateVars(order);
    Map<String, Object> filled = new HashMap<>();
    for (Map.Entry<String, Object> entry : raw.entrySet()) {
      Object value = entry.getValue();
      if (value instanceof String s) {
        filled.put(entry.getKey(), replaceVars(s, vars));
      } else {
        filled.put(entry.getKey(), value);
      }
    }
    // 添加甲乙方信息
    filled.put("partyAName", config.getCompanyName());
    filled.put("partyAAddress", config.getCompanyAddress());
    filled.put("partyBName", order.getRealName());
    filled.put("partyBIdCard", order.getIdCardNumber());
    filled.put("partyBPhone", order.getPhone());
    filled.put("partyBAddress", safe(extractHomeAddress(order)));
    filled.put("rentSchedule", buildRentSchedule(order));
    filled.put("deliveryItems", buildDeliveryItems(order));
    return filled;
  }

  private Map<String, String> buildTemplateVars(Order order) {
    int rentPerPeriod = extractMaxRent(order);
    int periods = order.getPeriods();
    int cycleDays = order.getCycleDays();
    BigDecimal rentPerPeriodAmount = BigDecimal.valueOf(rentPerPeriod);
    BigDecimal rentTotalAmount = rentPerPeriodAmount.multiply(BigDecimal.valueOf(periods));
    BigDecimal depositTotal = rentTotalAmount
      .multiply(BigDecimal.valueOf(order.getDepositRatio()))
      .setScale(2, RoundingMode.HALF_UP);
    BigDecimal depositPerPeriod = periods > 0
      ? depositTotal.divide(BigDecimal.valueOf(periods), 2, RoundingMode.HALF_UP)
      : BigDecimal.ZERO;
    BigDecimal rentDaily = cycleDays > 0
      ? rentPerPeriodAmount.divide(BigDecimal.valueOf(cycleDays), 2, RoundingMode.HALF_UP)
      : BigDecimal.ZERO;
    String depositPayType = depositTotal.compareTo(BigDecimal.ZERO) > 0 ? "2" : "1";
    BigDecimal firstPayRent = BigDecimal.valueOf(extractFirstRent(order));
    BigDecimal firstPayDeposit = depositPerPeriod;
    BigDecimal firstPayTotal = firstPayRent.add(firstPayDeposit);

    Map<String, String> vars = new HashMap<>();
    vars.put("orderId", safe(order.getId()));
    vars.put("productName", safe(order.getProductName()));
    vars.put("productSpec", "");
    vars.put("productQty", "1");
    vars.put("productFrameNo", "");
    vars.put("productAmount", formatAmount(rentTotalAmount));
    vars.put("periods", String.valueOf(order.getPeriods()));
    vars.put("cycleDays", String.valueOf(order.getCycleDays()));
    vars.put("depositRatio", String.valueOf(order.getDepositRatio()));
    vars.put("renterName", safe(order.getRealName()));
    vars.put("renterIdNumber", safe(order.getIdCardNumber()));
    vars.put("renterPhone", safe(order.getPhone()));
    vars.put("companyName", safe(config.getCompanyName()));
    vars.put("companyCertNo", safe(config.getCompanyCertNo()));
    vars.put("legalName", safe(config.getLegalName()));
    vars.put("legalCertNo", safe(config.getLegalCertNo()));
    vars.put("legalPhone", safe(config.getLegalPhone()));
    vars.put("leaseStart", safe(extractLeaseStart(order)));
    vars.put("leaseEnd", safe(extractLeaseEnd(order)));
    vars.put("leaseDays", String.valueOf(cycleDays > 0 && periods > 0 ? cycleDays * periods : 0));
    vars.put("rentPerPeriod", formatAmount(rentPerPeriodAmount));
    vars.put("rentDaily", formatAmount(rentDaily));
    vars.put("rentPeriodDays", String.valueOf(cycleDays));
    vars.put("rentTotalAmount", formatAmount(rentTotalAmount));
    vars.put("depositTotal", formatAmount(depositTotal));
    vars.put("depositPayType", depositPayType);
    vars.put("depositPeriods", depositTotal.compareTo(BigDecimal.ZERO) > 0 ? String.valueOf(periods) : "");
    vars.put("depositPeriodDays", depositTotal.compareTo(BigDecimal.ZERO) > 0 ? String.valueOf(cycleDays) : "");
    vars.put("depositPerPeriod", formatAmount(depositPerPeriod));
    vars.put("firstPayDate", safe(extractLeaseStart(order)));
    vars.put("firstPayRent", formatAmount(firstPayRent));
    vars.put("firstPayDeposit", formatAmount(firstPayDeposit));
    vars.put("firstPayTotal", formatAmount(firstPayTotal));
    vars.put("deliveryReceiveDate", safe(extractLeaseStart(order)));
    vars.put("deliveryContractDate", safe(extractLeaseStart(order)));
    vars.put("userSignDate", "");
    vars.put("homeAddress", safe(extractHomeAddress(order)));
    vars.put("workCity", safe(order.getWorkCity()));
    vars.put("occupation", safe(order.getOccupation()));
    vars.put("employmentStatus", safe(order.getEmploymentStatus()));
    vars.put("incomeRangeCode", safe(order.getIncomeRangeCode()));
    return vars;
  }

  private String replaceVars(String input, Map<String, String> vars) {
    String result = input;
    for (Map.Entry<String, String> entry : vars.entrySet()) {
      result = result.replace("{{" + entry.getKey() + "}}", entry.getValue());
    }
    return result;
  }

  private String extractPreviewUrl(Map<String, Object> result) {
    Map<String, Object> data = extractData(result);
    if (data == null) return "";
    Object preview = data.get("previewUrl");
    return preview == null ? "" : String.valueOf(preview);
  }

  private String extractSignUrl(Map<String, Object> result, String account) {
    Map<String, Object> data = extractData(result);
    if (data == null) return "";
    Object signUserObj = data.get("signUser");
    if (signUserObj instanceof List<?> list) {
      for (Object item : list) {
        if (!(item instanceof Map<?, ?> map)) continue;
        Object itemAccount = map.get("account");
        if (itemAccount != null && account.equals(String.valueOf(itemAccount))) {
          Object url = map.get("signUrl");
          if (url != null) return String.valueOf(url);
        }
      }
    }
    return "";
  }

  private String extractAuthUrl(Map<String, Object> data) {
    if (data == null) return "";
    Object url = data.get("url");
    if (url != null) return String.valueOf(url);
    Object authUrl = data.get("authUrl");
    if (authUrl != null) return String.valueOf(authUrl);
    Object identifyUrl = data.get("identifyUrl");
    if (identifyUrl != null) return String.valueOf(identifyUrl);
    Object h5Url = data.get("h5Url");
    if (h5Url != null) return String.valueOf(h5Url);
    return "";
  }

  private Map<String, Object> extractData(Map<String, Object> result) {
    if (result == null) return null;
    Object data = result.get("data");
    if (data instanceof Map<?, ?> map) {
      Map<String, Object> casted = new HashMap<>();
      for (Map.Entry<?, ?> entry : map.entrySet()) {
        if (entry.getKey() != null) {
          casted.put(String.valueOf(entry.getKey()), entry.getValue());
        }
      }
      return casted;
    }
    return null;
  }

  private int extractMaxRent(Order order) {
    if (order.getRepaymentPlan() == null || order.getRepaymentPlan().isEmpty()) return 0;
    return order.getRepaymentPlan().stream().mapToInt(p -> p.getAmount()).max().orElse(0);
  }

  private int extractFirstRent(Order order) {
    if (order.getRepaymentPlan() == null || order.getRepaymentPlan().isEmpty()) return 0;
    return order.getRepaymentPlan().get(0).getAmount();
  }

  private List<Map<String, Object>> buildRentSchedule(Order order) {
    List<Map<String, Object>> rows = new ArrayList<>();
    if (order.getRepaymentPlan() == null || order.getRepaymentPlan().isEmpty()) return rows;
    int rentPerPeriod = extractMaxRent(order);
    BigDecimal rentPerPeriodAmount = BigDecimal.valueOf(rentPerPeriod);
    BigDecimal rentTotalAmount = rentPerPeriodAmount.multiply(BigDecimal.valueOf(order.getPeriods()));
    BigDecimal depositTotal = rentTotalAmount
      .multiply(BigDecimal.valueOf(order.getDepositRatio()))
      .setScale(2, RoundingMode.HALF_UP);
    BigDecimal depositPerPeriod = order.getPeriods() > 0
      ? depositTotal.divide(BigDecimal.valueOf(order.getPeriods()), 2, RoundingMode.HALF_UP)
      : BigDecimal.ZERO;
    for (var item : order.getRepaymentPlan()) {
      Map<String, Object> row = new HashMap<>();
      row.put("periodNo", "第" + item.getPeriod() + "期");
      row.put("payDate", String.valueOf(item.getDueDate()));
      BigDecimal rentAmount = BigDecimal.valueOf(item.getAmount());
      BigDecimal depositAmount = depositTotal.compareTo(BigDecimal.ZERO) > 0 ? depositPerPeriod : BigDecimal.ZERO;
      BigDecimal totalAmount = rentAmount.add(depositAmount);
      row.put("rentAmount", formatAmount(rentAmount));
      row.put("depositAmount", formatAmount(depositAmount));
      row.put("totalAmount", formatAmount(totalAmount));
      rows.add(row);
    }
    return rows;
  }

  private List<Map<String, Object>> buildDeliveryItems(Order order) {
    List<Map<String, Object>> rows = new ArrayList<>();
    Map<String, Object> row = new HashMap<>();
    row.put("itemName", safe(order.getProductName()));
    row.put("itemModel", "");
    row.put("itemQty", "1");
    rows.add(row);
    return rows;
  }

  private String extractLeaseStart(Order order) {
    if (order.getRepaymentPlan() == null || order.getRepaymentPlan().isEmpty()) return "";
    return String.valueOf(order.getRepaymentPlan().get(0).getDueDate());
  }

  private String extractLeaseEnd(Order order) {
    if (order.getRepaymentPlan() == null || order.getRepaymentPlan().isEmpty()) return "";
    return String.valueOf(order.getRepaymentPlan().get(order.getRepaymentPlan().size() - 1).getDueDate());
  }

  private String extractHomeAddress(Order order) {
    StringBuilder builder = new StringBuilder();
    if (order.getHomeProvinceCode() != null) builder.append(order.getHomeProvinceCode());
    if (order.getHomeCityCode() != null) builder.append(order.getHomeCityCode());
    if (order.getHomeDistrictCode() != null) builder.append(order.getHomeDistrictCode());
    if (order.getHomeAddressDetail() != null) builder.append(order.getHomeAddressDetail());
    return builder.toString();
  }

  private Instant parseInstant(String value) {
    if (value == null || value.isBlank()) return Instant.now();
    try {
      return Instant.parse(value.trim());
    } catch (Exception ex) {
      try {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime local = LocalDateTime.parse(value.trim(), formatter);
        return local.atZone(ZoneId.of("Asia/Shanghai")).toInstant();
      } catch (Exception ignored) {
        return Instant.now();
      }
    }
  }

  private Path resolveUploadDir() {
    String dir = appProperties.getUpload().getDir();
    if (dir == null || dir.isBlank()) dir = "uploads";
    return Path.of(dir).toAbsolutePath().normalize();
  }

  private String sanitize(String value) {
    if (value == null) return "unknown";
    return value.replaceAll("[^A-Za-z0-9_-]", "_");
  }

  private String formatAmount(BigDecimal value) {
    if (value == null) return "0.00";
    return value.setScale(2, RoundingMode.HALF_UP).toPlainString();
  }

  private String safe(String value) {
    return value == null ? "" : value;
  }
}
